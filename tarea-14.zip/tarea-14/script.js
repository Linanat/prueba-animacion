
$(function(){

   $(".primero").mouseenter(function(){ // . Etiqueta que llama a una clase que seria .primero
                                        // mousseenter: AL pasar el ratón sobre el primer párrafo el segundo párrafo se deslizara hacia abajo como efecto acordeon.
    $("#parrafo-2").slideDown();
   });

   $(".primero").mouseleave(function(){  // mouseleave: Al pasar el ratón por el primer párrafo el segundo párrafo se deslizara hacia arriba como efecto acordeon.
    $("#parrafo-2").slideUp();
   });

   //BOTONES

   $("#btn-hide").click(function(){ // Con la etiqueta # llamas la id de btn-hide. 
    $("#parrafo-1").hide();     // La funcion .hide hace que oculte el primer párrafo al apretar el boton Hide.
    });

    $('#btn-show').click(function(){
    $("#parrafo-1").show();     // La funcion .show hace que muestre el primer párrafo al apretar el boton Hide.
    });

    $("#btn-desaparecer").dblclick(function(){ //  dblclick: Hará que al apretar 2 veces seguidas en el boton "desaparecer" el primer parrafo desaparecerá con .fadeOut(); .
    $("#parrafo-1").fadeOut();
    });
    

})


    $(".titulo").on ({  // Al poner $(".titulo") selecciona todos los elementos con la clase titulo.
        mouseenter: function() {
        $(this).next(".contenido").stop(true, true).slideDown(); // la función $(this) llama al elemento especifíco que está en html, en este caso a todas mis clases llamadas ".contenido"
        },
        mouseleave: function() {
        $(this).next(".contenido").stop(true, true).slideUp(); // .stop(true, true) Sirve para evitar que la animacion de deslizar y deslizar hacia abajo; .slideDown() y .slideUp() no tengan un efecto rebote al pasar muchas veces el mouse sobre ellas.
        }
  });

    $("#enviar").click(function() {
        $(this).text("¡Tu mensaje ha sido enviado!");

       
});

    $("#enviar").hover(
        function() {
        // Mouse entra
        $(this).css("background-color", "blue");
        },
        function() {
        // Mouse sale
        $(this).css("background-color", "red");
        }
    );

    $("form").submit(function(event) {
        event.preventDefault(); // Evita que se envíe de forma tradicional
      
        if (nombre && correo && mensaje) {
          alert("Formulario enviado correctamente");
    
        } else {
          alert("Por favor, completa todos los campos.");
        }
      });
      
  
 


